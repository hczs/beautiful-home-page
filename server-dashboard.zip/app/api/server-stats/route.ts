import { NextResponse } from "next/server"
import { exec } from "child_process"
import { promisify } from "util"
import os from "os"

const execAsync = promisify(exec)

interface ServerStats {
  cpu: number
  memory: number
  disk: number
  network: number
  uptime: string
  cpuTemp: number
}

// 获取CPU温度（Linux/macOS）
async function getCPUTemperature(): Promise<number> {
  try {
    // Linux系统尝试读取温度传感器
    if (process.platform === "linux") {
      try {
        const { stdout } = await execAsync("cat /sys/class/thermal/thermal_zone0/temp")
        const temp = Number.parseInt(stdout.trim()) / 1000 // 转换为摄氏度
        return Math.round(temp)
      } catch {
        // 如果上面的方法失败，尝试使用sensors命令
        try {
          const { stdout } = await execAsync(
            "sensors | grep \"Core 0\" | awk '{print $3}' | sed 's/+//g' | sed 's/°C//g'",
          )
          return Math.round(Number.parseFloat(stdout.trim()) || 0)
        } catch {
          return Math.round(Math.random() * 20 + 40) // 模拟温度 40-60°C
        }
      }
    }

    // macOS系统
    if (process.platform === "darwin") {
      try {
        const { stdout } = await execAsync('sudo powermetrics --samplers smc -n 1 | grep "CPU die temperature"')
        const match = stdout.match(/(\d+\.\d+)/)
        return match ? Math.round(Number.parseFloat(match[1])) : Math.round(Math.random() * 20 + 40)
      } catch {
        return Math.round(Math.random() * 20 + 40) // 模拟温度
      }
    }

    // Windows或其他系统，返回模拟数据
    return Math.round(Math.random() * 20 + 40)
  } catch {
    return Math.round(Math.random() * 20 + 40) // 模拟温度 40-60°C
  }
}

// 获取CPU使用率
function getCPUUsage(): Promise<number> {
  return new Promise((resolve) => {
    const startMeasure = process.cpuUsage()
    const startTime = process.hrtime()

    setTimeout(() => {
      const endMeasure = process.cpuUsage(startMeasure)
      const endTime = process.hrtime(startTime)

      const totalTime = endTime[0] * 1000000 + endTime[1] / 1000
      const totalUsage = endMeasure.user + endMeasure.system
      const cpuPercent = (totalUsage / totalTime) * 100

      resolve(Math.min(Math.round(cpuPercent), 100))
    }, 100)
  })
}

// 获取内存使用率
function getMemoryUsage(): number {
  const totalMem = os.totalmem()
  const freeMem = os.freemem()
  const usedMem = totalMem - freeMem
  return Math.round((usedMem / totalMem) * 100)
}

// 获取磁盘使用率（模拟）
async function getDiskUsage(): Promise<number> {
  try {
    if (process.platform === "linux" || process.platform === "darwin") {
      const { stdout } = await execAsync("df -h / | tail -1 | awk '{print $5}' | sed 's/%//g'")
      return Number.parseInt(stdout.trim()) || Math.round(Math.random() * 50 + 20)
    }
    return Math.round(Math.random() * 50 + 20) // 模拟数据
  } catch {
    return Math.round(Math.random() * 50 + 20) // 模拟数据
  }
}

// 格式化运行时间
function formatUptime(): string {
  const uptime = os.uptime()
  const days = Math.floor(uptime / 86400)
  const hours = Math.floor((uptime % 86400) / 3600)
  const minutes = Math.floor((uptime % 3600) / 60)

  if (days > 0) {
    return `${days}天 ${hours}小时`
  } else if (hours > 0) {
    return `${hours}小时 ${minutes}分钟`
  } else {
    return `${minutes}分钟`
  }
}

export async function GET() {
  try {
    const [cpu, cpuTemp, disk] = await Promise.all([getCPUUsage(), getCPUTemperature(), getDiskUsage()])

    const stats: ServerStats = {
      cpu,
      memory: getMemoryUsage(),
      disk,
      network: Math.round(Math.random() * 50 + 10), // 模拟网络流量
      uptime: formatUptime(),
      cpuTemp,
    }

    return NextResponse.json(stats)
  } catch (error) {
    console.error("Failed to get server stats:", error)

    // 返回模拟数据作为后备
    const fallbackStats: ServerStats = {
      cpu: Math.round(Math.random() * 50 + 20),
      memory: Math.round(Math.random() * 50 + 30),
      disk: Math.round(Math.random() * 50 + 20),
      network: Math.round(Math.random() * 50 + 10),
      uptime: "模拟数据",
      cpuTemp: Math.round(Math.random() * 20 + 40),
    }

    return NextResponse.json(fallbackStats)
  }
}
